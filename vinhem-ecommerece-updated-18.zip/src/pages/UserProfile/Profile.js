import "./Css/Profile.css";

export const Profile = () => {
  return (
    <div>
      <div class="ffhfdf">
        <div class="container-fluid">
            <div class="fbghdfg">
                <div class="row">
                    <div class="col-lg-3">
                        <div class="hdkgdfg">
                            <div class="dfbdf">
                                <h5>Settings</h5>
                                <p>You Can Find all settings here...</p>

                            </div>
                            <button class="dfgdfg">
                                <i class="fa-solid fa-user"></i> My Profile

                            </button>

                             <button class="dfgdfg1">
                                <i class="fa-regular fa-heart"></i> Wishlist

                            </button>

                             <button class="dfgdfg1">
                                <i class="fa-solid fa-clock-rotate-left"></i> Order History

                            </button>

                             <button class="dfgdfg1">
                                <i class="fa-solid fa-ban"></i> Cancel Order

                            </button>

                             <button class="dfgdfg1">
                               <i class="fa-solid fa-eye-low-vision"></i> Password Change

                            </button>
                            <div class="xfbjhxfvgfx">
                                <button><i class="fa-solid fa-circle-info"></i> Get Help</button> <br />
                                <button><i class="fa-solid fa-right-from-bracket"></i> Logout</button>
                            </div>


                        </div>
                    </div>
                    <div class="col-lg-9">
                        <div class="fgcbdfgdf">
                            <div class="dfjhdsbfsdf">
                                <div class="fbhdfs">
                                    <h4>Profile Information</h4>
                                    <button><i class="fa-solid fa-pen"></i> Edit</button>
                                </div>
                            </div>

                            <div class="dfghdfgdf">
                                <div class="sdfjhsdfs"><img src="./image/testiphoto (3).png" alt="" /></div>
                                <div class="dfbghdfg">
                                    <h5>Ravindra Jadeja</h5>
                                    <p>Customer Service  Maneger</p>
                                </div>
                             
                            </div>

                            <hr />
                            <div class="sdfnsdjkfsdf">
                                <div class="fdndfjh">
                                    <h5>Personal Details</h5>
                                </div>
                                <div class="sdksdfsdf">
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="dhfsdfd">
                                                <label for="">First Name</label>
                                                <input type="text" class="form-control" placeholder="Ravindra " disabled />
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="dhfsdfd">
                                                <label for="">Last Name</label>
                                                <input type="text" class="form-control" placeholder="Jadeja " disabled />
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="dhfsdfd">
                                                <label for="">Email Adress</label>
                                                <input type="text" class="form-control" placeholder="jaddu@gmail.com" disabled />
                                            </div>
                                        </div>

                                         <div class="col-lg-4">
                                            <div class="dhfsdfd">
                                                <label for="">Phone Number</label>
                                                <input type="text" class="form-control" placeholder="7854952585" disabled />
                                            </div>
                                        </div>

                                         <div class="col-lg-4">
                                            <div class="dhfsdfd">
                                                <label for="">Gendar</label>
                                                <input type="text" class="form-control" placeholder="Male" disabled />
                                            </div>
                                        </div>

                                         <div class="col-lg-4">
                                            <div class="dhfsdfd">
                                                <label for="">Bio</label>
                                                <input type="text" class="form-control" placeholder="Customer Service Manager" disabled />
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="dhfsdfd">
                                                <label for="">Date Of Birth</label>
                                                <input type="text" class="form-control" placeholder="10 june 2004" disabled />
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="dhfsdfd">
                                                <label for="">National ID</label>
                                                <input type="text" class="form-control" placeholder="658-8568-8586" disabled />
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="dfgdfg6526">
                                    <h5>Adress Details</h5>
                                </div>

                                <div class="dfgdfhdf5156">
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="dhfsdfd">
                                                <label for="">Country</label>
                                                <input type="text" class="form-control" placeholder="India" disabled />
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="dhfsdfd">
                                                <label for="">City</label>
                                                <input type="text" class="form-control" placeholder="Jamnagar" disabled />
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="dhfsdfd">
                                                <label for="">Pin Code</label>
                                                <input type="text" class="form-control" placeholder="742121 " disabled />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
  )
}

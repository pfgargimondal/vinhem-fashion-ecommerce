import "./Css/Wishlist.css";

export const Wishlist = () => {
  return (
    <div>
      <div class="ffhfdf">
        <div class="container-fluid">
            <div class="fbghdfg">
                <div class="row">
                    <div class="col-lg-3">
                        <div class="hdkgdfg">
                            <div class="dfbdf">
                                <h5>Settings</h5>
                                <p>You Can Find all settings here...</p>

                            </div>
                            <button class="dfgdfg">
                                <i class="fa-solid fa-user"></i> My Profile

                            </button>

                             <button class="dfgdfg1">
                                <i class="fa-regular fa-heart"></i> Wishlist

                            </button>

                             <button class="dfgdfg1">
                                <i class="fa-solid fa-clock-rotate-left"></i> Order History

                            </button>

                             <button class="dfgdfg1">
                                <i class="fa-solid fa-ban"></i> Cancel Order

                            </button>

                             <button class="dfgdfg1">
                               <i class="fa-solid fa-eye-low-vision"></i> Password Change

                            </button>
                            <div class="xfbjhxfvgfx">
                                <button><i class="fa-solid fa-circle-info"></i> Get Help</button> <br />
                                <button><i class="fa-solid fa-right-from-bracket"></i> Logout</button>
                            </div>


                        </div>
                    </div>
                    <div class="col-lg-9">
                        <div class="fgcbdfgdf">
                            <div class="dfjhdsbfsdf">
                                <div class="fbhdfs">
                                    <h4>Profile Information</h4>
                                    <button><i class="fa-solid fa-pen"></i> Edit</button>
                                </div>
                            </div>

                            <div class="dfghdfgdf">
                                <div class="sdfjhsdfs"><img src="./images/testiphoto (3).png" alt="" /></div>
                                <div class="dfbghdfg">
                                    <h5>Ravindra Jadeja</h5>
                                    <p>Customer Service  Maneger</p>
                                </div>
                             
                            </div>

                            <hr />

                            <div class="fbgdfhgdfgdg">
                                
                                



                            </div>



                           

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
  )
}

import "./Css/CustomizeModal.css";

export const CustomizeModal = () => {
  return (
    <div>CustomizeModal</div>
  )
}
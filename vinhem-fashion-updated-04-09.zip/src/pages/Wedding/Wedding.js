import { FooterTopComponent } from "../../components/Others/FooterTopComponent";
import "./Css/Wedding.css";
import "./Css/WeddingResponsive.css";

export const Wedding = () => {
  return (
    <>
      <div className="dfgjhdfgdf">
        <div className="fvxvfdfsf">
          <div className="fvgndfjhgdfg">
            <img src="./images/wedding.png" alt="" />
          </div>
        </div>
      </div>
      <div className="sdgdfhbgdfr">
        <div className="container-fluid">
          <div className="dfgbdfjhgdf">
            <h2>Shop by Occasion</h2>
          </div>
          <div className="fgjhdfgf row">
            <div className="col-lg-3 mb-4">
              <div
              className="dfgdfg255"
              style={{ backgroundImage: "url('./images/weddingdress (1).jpg')" }}
            >
              <div className="overlay-black">
                <div className="dfbghf">
                  <h4>Wedding</h4>
                  <button>SHOP NOW</button>
                </div>
              </div>
            </div>
            </div>
            

            <div className="col-lg-3 mb-4">
              <div
              className="dfgdfg255"
              style={{ backgroundImage: "url('./images/weddingdress (2).jpg')" }}
            >
              <div className="overlay-black">
                <div className="dfbghf">
                  <h4>Sangeet</h4>
                  <button>SHOP NOW</button>
                </div>
              </div>
            </div>
            </div>
            

            <div className="col-lg-3 mb-4">
              <div
              className="dfgdfg255"
              style={{ backgroundImage: "url('./images/weddingdress (3).jpg')" }}
            >
              <div className="overlay-black">
                <div className="dfbghf">
                  <h4>Reception &amp; Cocktail</h4>
                  <button>SHOP NOW</button>
                </div>
              </div>
            </div>
            </div>
            

            <div className="col-lg-3 mb-4">
              <div
              className="dfgdfg255"
              style={{ backgroundImage: "url('./images/weddingdress (4).jpg')" }}
            >
              <div className="overlay-black">
                <div className="dfbghf">
                  <h4>Mehendi</h4>
                  <button>SHOP NOW</button>
                </div>
              </div>
            </div>
            </div>
            

            <div className="col-lg-3 mb-4">
              <div
              className="dfgdfg255"
              style={{ backgroundImage: "url('./images/weddingdress (5).jpg')" }}
            >
              <div className="overlay-black">
                <div className="dfbghf">
                  <h4>Roka</h4>
                  <button>SHOP NOW</button>
                </div>
              </div>
            </div>
            </div>
            
            <div className="col-lg-3 mb-4">
              <div
              className="dfgdfg255"
              style={{ backgroundImage: "url('./images/weddingdress (3).jpg')" }}
            >
              <div className="overlay-black">
                <div className="dfbghf">
                  <h4>Reception &amp; Cocktail</h4>
                  <button>SHOP NOW</button>
                </div>
              </div>
            </div>
            </div>
            

            <div className="col-lg-3 mb-4">
              <div
              className="dfgdfg255"
              style={{ backgroundImage: "url('./images/weddingdress (4).jpg')" }}
            >
              <div className="overlay-black">
                <div className="dfbghf">
                  <h4>Mehendi</h4>
                  <button>SHOP NOW</button>
                </div>
              </div>
            </div>
            </div>
            

            <div className="col-lg-3 mb-4">
              <div
              className="dfgdfg255"
              style={{ backgroundImage: "url('./images/weddingdress (5).jpg')" }}
            >
              <div className="overlay-black">
                <div className="dfbghf">
                  <h4>Roka</h4>
                  <button>SHOP NOW</button>
                </div>
              </div>
            </div>
            </div>
          </div>
        </div>
      </div>
      <div className="sdfjksdgsdfgsdf">
        <div className="container-fluid">
          <div className="dfgbdfjhgdf">
            <h2>Shop by Designer</h2>
          </div>
          <div className="fbghdfgdfgf">
            <div className="row">
              <div className="col-lg-4 col-md-6 col-sm-6 col-12">
                <div
                  className="jdfkdf"
                  style={{
                    backgroundImage: "url('./images/wedding-product11 (1).jpg')"
                  }}
                >
                  <div className="overlay-black1">
                    <div className="dfbghf1">
                      <h4>Roka</h4>
                      <button>SHOP NOW</button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-lg-4 col-md-6 col-sm-6 col-12">
                <div
                  className="jdfkdf"
                  style={{
                    backgroundImage: "url('./images/wedding-product11 (1).webp')"
                  }}
                >
                  <div className="overlay-black1">
                    <div className="dfbghf1">
                      <h4>Roka</h4>
                      <button>SHOP NOW</button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-lg-4 col-md-6 col-sm-6 col-12">
                <div
                  className="jdfkdf"
                  style={{
                    backgroundImage: "url('./images/wedding-product11 (2).jpg')"
                  }}
                >
                  <div className="overlay-black1">
                    <div className="dfbghf1">
                      <h4>Roka</h4>
                      <button>SHOP NOW</button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-lg-4 col-md-6 col-sm-6 col-12">
                <div
                  className="jdfkdf"
                  style={{
                    backgroundImage: "url('./images/wedding-product11 (3).jpg')"
                  }}
                >
                  <div className="overlay-black1">
                    <div className="dfbghf1">
                      <h4>Roka</h4>
                      <button>SHOP NOW</button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-lg-4 col-md-6 col-sm-6 col-12">
                <div
                  className="jdfkdf"
                  style={{
                    backgroundImage: "url('./images/wedding-product11 (4).jpg')"
                  }}
                >
                  <div className="overlay-black1">
                    <div className="dfbghf1">
                      <h4>Roka</h4>
                      <button>SHOP NOW</button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-lg-4 col-md-6 col-sm-6 col-12">
                <div
                  className="jdfkdf"
                  style={{
                    backgroundImage: "url('./images/wedding-product11 (5).jpg')"
                  }}
                >
                  <div className="overlay-black1">
                    <div className="dfbghf1">
                      <h4>Roka</h4>
                      <button>SHOP NOW</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="dfghjhufggdfg">
        <div className="container-fluid">
          <div className="dfgbdfjhgdf">
            <h2>Curated by Vinhem Fasion</h2>
          </div>
          <div className="dfbgjhdfbgdfg">
            <div className="row">
              <div className="col-lg-4 col-md-6 col-sm-6 col-12">
                <div
                  className="dfbhhfgdf"
                  style={{ backgroundImage: "url('./images/weddingbigg (1).jpg')" }}
                >
                  <div className="overlay-black2">
                    <div className="dfbghf2">
                      <h4>Roka</h4>
                      <button>SHOP NOW</button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-lg-4 col-md-6 col-sm-6 col-12">
                <div
                  className="dfbhhfgdf"
                  style={{ backgroundImage: "url('./images/weddingbigg (1).webp')" }}
                >
                  <div className="overlay-black2">
                    <div className="dfbghf2">
                      <h4>Roka</h4>
                      <button>SHOP NOW</button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-lg-4 col-md-6 col-sm-6 col-12">
                <div
                  className="dfbhhfgdf"
                  style={{ backgroundImage: "url('./images/weddingbigg (2).webp')" }}
                >
                  <div className="overlay-black2">
                    <div className="dfbghf2">
                      <h4>Roka</h4>
                      <button>SHOP NOW</button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-lg-4 col-md-6 col-sm-6 col-12">
                <div
                  className="dfbhhfgdf"
                  style={{ backgroundImage: "url('./images/weddingbigg (1).jpg')" }}
                >
                  <div className="overlay-black2">
                    <div className="dfbghf2">
                      <h4>Roka</h4>
                      <button>SHOP NOW</button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-lg-4 col-md-6 col-sm-6 col-12">
                <div
                  className="dfbhhfgdf"
                  style={{ backgroundImage: "url('./images/weddingbigg (1).webp')" }}
                >
                  <div className="overlay-black2">
                    <div className="dfbghf2">
                      <h4>Roka</h4>
                      <button>SHOP NOW</button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-lg-4 col-md-6 col-sm-6 col-12">
                <div
                  className="dfbhhfgdf"
                  style={{ backgroundImage: "url('./images/weddingbigg (2).webp')" }}
                >
                  <div className="overlay-black2">
                    <div className="dfbghf2">
                      <h4>Roka</h4>
                      <button>SHOP NOW</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="fgnhdfjhugdfgsd">
        <div className="container-fluid">
          <div className="dfgbdfjhgdf">
            <h2>Shop by Designer</h2>
          </div>
          <div className="fhfgdfgfdg">
            <div className="row">
              <div className="col-lg-3 col-md-6 col-sm-6 col-12">
                <div
                  className="dfbhhfgdf55"
                  style={{ backgroundImage: "url('./images/webpro (1).jpg')" }}
                >
                  <div className="overlay-black3">
                    <div className="dfbghf3">
                      <h4>Roka</h4>
                      <button>SHOP NOW</button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-lg-3 col-md-6 col-sm-6 col-12">
                <div
                  className="dfbhhfgdf55"
                  style={{ backgroundImage: "url('./images/webpro (1).webp')" }}
                >
                  <div className="overlay-black3">
                    <div className="dfbghf3">
                      <h4>Roka</h4>
                      <button>SHOP NOW</button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-lg-3 col-md-6 col-sm-6 col-12">
                <div
                  className="dfbhhfgdf55"
                  style={{ backgroundImage: "url('./images/webpro (2).webp')" }}
                >
                  <div className="overlay-black3">
                    <div className="dfbghf3">
                      <h4>Roka</h4>
                      <button>SHOP NOW</button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-lg-3 col-md-6 col-sm-6 col-12">
                <div
                  className="dfbhhfgdf55"
                  style={{ backgroundImage: "url('./images/webpro (3).webp')" }}
                >
                  <div className="overlay-black3">
                    <div className="dfbghf3">
                      <h4>Roka</h4>
                      <button>SHOP NOW</button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-lg-3 col-md-6 col-sm-6 col-12">
                <div
                  className="dfbhhfgdf55"
                  style={{ backgroundImage: "url('./images/webpro (4).webp')" }}
                >
                  <div className="overlay-black3">
                    <div className="dfbghf3">
                      <h4>Roka</h4>
                      <button>SHOP NOW</button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-lg-3 col-md-6 col-sm-6 col-12">
                <div
                  className="dfbhhfgdf55"
                  style={{ backgroundImage: "url('./images/webpro (5).webp')" }}
                >
                  <div className="overlay-black3">
                    <div className="dfbghf3">
                      <h4>Roka</h4>
                      <button>SHOP NOW</button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-lg-3 col-md-6 col-sm-6 col-12">
                <div
                  className="dfbhhfgdf55"
                  style={{ backgroundImage: "url('./images/webpro (6).webp')" }}
                >
                  <div className="overlay-black3">
                    <div className="dfbghf3">
                      <h4>Roka</h4>
                      <button>SHOP NOW</button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-lg-3 col-md-6 col-sm-6 col-12">
                <div
                  className="dfbhhfgdf55"
                  style={{ backgroundImage: "url('./images/webpro (7).webp')" }}
                >
                  <div className="overlay-black3">
                    <div className="dfbghf3">
                      <h4>Roka</h4>
                      <button>SHOP NOW</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="fgndfjhgfgds">
        <div className="container-fluid">
          <div
            className="dfgdfgfd"
            style={{ backgroundImage: "url('./images/bannercontent3.png')" }}
          >
            <div className="sdjhds">
              <h4>Vinhem Fashion Gift Cards | Flat 10% OFF</h4>
              <h3>Perfect Present for any occasion</h3>
            </div>
          </div>
        </div>
      </div>
      <div className="fgjhfbgdfjh565">
        <div className="container-fluid">
          <div className="dfgbdfjhgdf">
            <h2>Shop by Designer</h2>
          </div>
          <div className="dbgjkdffd52">
            <div className="row">
              <div className="col-lg-4">
                <div className="fbghjdfgfd">
                  <div className="row">
                    <div className="col-lg-6 col-md-6 col-sm-6 col-12">
                      <div className="ffdgf548">
                        <img src="./images/treand (1).webp" alt="" />
                      </div>
                    </div>
                    <div className="col-lg-6 col-md-6 col-sm-6 col-12">
                      <div className="ffdgf548">
                        <img src="./images/treand (2).webp" alt="" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="col-lg-4 col-12">
                <div className="fghbjkfgfg145">
                  <h2>Trending Now</h2>
                  <p>The wedding trends everyone’s talking about</p>
                </div>
              </div>
              
              <div className="col-lg-4">
                <div className="fbghjdfgfd">
                  <div className="row">
                    <div className="col-lg-6 col-md-6 col-sm-6 col-12 pe-0 ps-0">
                      <div className="ffdgf548">
                        <img src="./images/treand (3).webp" alt="" />
                      </div>
                    </div>
                    <div className="col-lg-6 col-md-6 col-sm-6 col-12 pe-0 ps-0">
                      <div className="ffdgf548">
                        <img src="./images/treand (4).webp" alt="" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="fgnhdfjhugdfgsd">
        <div className="container-fluid">
          <div className="dfgbdfjhgdf">
            <h2>Shop by Designer</h2>
          </div>
          <div className="fhfgdfgfdg">
            <div className="row">
              <div className="col-lg-3 col-md-6 col-sm-6 col-12">
                <div
                  className="dfbhhfgdf55"
                  style={{ backgroundImage: "url('./images/webpro (1).jpg')" }}
                >
                  <div className="overlay-black3">
                    <div className="dfbghf3">
                      <h4>Roka</h4>
                      <button>SHOP NOW</button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-lg-3 col-md-6 col-sm-6 col-12">
                <div
                  className="dfbhhfgdf55"
                  style={{ backgroundImage: "url('./images/webpro (1).webp')" }}
                >
                  <div className="overlay-black3">
                    <div className="dfbghf3">
                      <h4>Roka</h4>
                      <button>SHOP NOW</button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-lg-3 col-md-6 col-sm-6 col-12">
                <div
                  className="dfbhhfgdf55"
                  style={{ backgroundImage: "url('./images/webpro (2).webp')" }}
                >
                  <div className="overlay-black3">
                    <div className="dfbghf3">
                      <h4>Roka</h4>
                      <button>SHOP NOW</button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-lg-3 col-md-6 col-sm-6 col-12">
                <div
                  className="dfbhhfgdf55"
                  style={{ backgroundImage: "url('./images/webpro (3).webp')" }}
                >
                  <div className="overlay-black3">
                    <div className="dfbghf3">
                      <h4>Roka</h4>
                      <button>SHOP NOW</button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-lg-3 col-md-6 col-sm-6 col-12">
                <div
                  className="dfbhhfgdf55"
                  style={{ backgroundImage: "url('./images/webpro (4).webp')" }}
                >
                  <div className="overlay-black3">
                    <div className="dfbghf3">
                      <h4>Roka</h4>
                      <button>SHOP NOW</button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-lg-3 col-md-6 col-sm-6 col-12">
                <div
                  className="dfbhhfgdf55"
                  style={{ backgroundImage: "url('./images/webpro (5).webp')" }}
                >
                  <div className="overlay-black3">
                    <div className="dfbghf3">
                      <h4>Roka</h4>
                      <button>SHOP NOW</button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-lg-3 col-md-6 col-sm-6 col-12">
                <div
                  className="dfbhhfgdf55"
                  style={{ backgroundImage: "url('./images/webpro (6).webp')" }}
                >
                  <div className="overlay-black3">
                    <div className="dfbghf3">
                      <h4>Roka</h4>
                      <button>SHOP NOW</button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-lg-3 col-md-6 col-sm-6 col-12">
                <div
                  className="dfbhhfgdf55"
                  style={{ backgroundImage: "url('./images/webpro (7).webp')" }}
                >
                  <div className="overlay-black3">
                    <div className="dfbghf3">
                      <h4>Roka</h4>
                      <button>SHOP NOW</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="fgjhfbgdfjh565">
        <div className="container-fluid">
          <div className="dfgbdfjhgdf">
            <h2>Shop by Designer</h2>
          </div>
          <div className="dbgjkdffd52">
            <div className="row">
              <div className="col-lg-4">
                <div className="fbghjdfgfd">
                  <div className="row">
                    <div className="col-lg-6 col-md-6 col-sm-6 col-12">
                      <div className="ffdgf548">
                        <img src="./images/treand (5).webp" alt="" />
                      </div>
                    </div>
                    <div className="col-lg-6 col-md-6 col-sm-6 col-12">
                      <div className="ffdgf548">
                        <img src="./images/treand (6).webp" alt="" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-lg-4">
                <div className="fghbjkfgfg145">
                  <h2>Trending Now</h2>
                  <p>The wedding trends everyone’s talking about</p>
                </div>
              </div>

              <div className="col-lg-4">
                <div className="fbghjdfgfd">
                  <div className="row">
                    <div className="col-lg-6 col-md-6 col-sm-6 col-12 pe-0 ps-0">
                      <div className="ffdgf548">
                        <img src="./images/treand (7).webp" alt="" />
                      </div>
                    </div>
                    <div className="col-lg-6 col-md-6 col-sm-6 col-12 pe-0 ps-0">
                      <div className="ffdgf548">
                        <img src="./images/treand (8).webp" alt="" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <hr />
      <FooterTopComponent />
    </>
  )
}
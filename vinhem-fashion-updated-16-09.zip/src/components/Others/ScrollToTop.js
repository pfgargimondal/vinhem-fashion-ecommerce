export const ScrollToTop = () => {
  return null;
}
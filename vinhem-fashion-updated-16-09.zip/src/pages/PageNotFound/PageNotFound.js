import "./Css/PageNotFound.css";

export const PageNotFound = () => {
    return (
        <div>PageNotFound</div>
    )
}